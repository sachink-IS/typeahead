let cities = [
  { name: "Alabama" }, 
  { name: "Alaska" }, 
  { name: "Massachusetts" }, 
  { name: "Michigan" }, 
  { name: "Vermont" }, 
  { name: "Virginia" }, 
  { name: "Washington" }, 
  { name: "Wyoming" }
]

export default cities;